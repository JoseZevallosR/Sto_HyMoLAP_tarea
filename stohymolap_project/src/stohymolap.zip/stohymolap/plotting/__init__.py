"""Subpaquete plotting de stohymolap."""
