"""Subpaquete hydro de stohymolap."""
