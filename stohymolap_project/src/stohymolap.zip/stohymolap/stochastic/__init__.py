"""Subpaquete stochastic de stohymolap."""
