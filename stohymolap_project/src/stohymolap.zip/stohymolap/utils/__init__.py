"""Subpaquete utils de stohymolap."""
