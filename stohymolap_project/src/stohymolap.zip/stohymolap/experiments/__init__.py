"""Subpaquete experiments de stohymolap."""
