"""Subpaquete calibration de stohymolap."""
