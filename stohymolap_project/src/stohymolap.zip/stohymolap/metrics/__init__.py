"""Subpaquete metrics de stohymolap."""
