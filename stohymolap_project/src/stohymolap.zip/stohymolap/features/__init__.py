"""Subpaquete features de stohymolap."""
