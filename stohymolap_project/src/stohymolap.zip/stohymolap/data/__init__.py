"""Subpaquete data de stohymolap."""
